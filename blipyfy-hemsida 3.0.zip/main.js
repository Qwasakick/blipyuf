(function(){
  var root=document.documentElement;
  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var y=document.getElementById('year'); if(y) y.textContent=new Date().getFullYear();

  /* ---------- Toasts ---------- */
  var toaster=document.querySelector('.toaster');
  function layout(){var items=[].slice.call(toaster.querySelectorAll('.toast:not([data-removed])')).reverse();items.forEach(function(t,i){t.style.setProperty('--i',i);t.dataset.i=Math.min(i,3);});}
  function toast(msg){
    if(!toaster) return;
    var t=document.createElement('li');t.className='toast';t.textContent=msg;toaster.appendChild(t);
    requestAnimationFrame(function(){requestAnimationFrame(function(){t.setAttribute('data-mounted','');layout();});});
    var left=2600,start=Date.now(),timer;
    function run(){start=Date.now();timer=setTimeout(remove,left);}
    function remove(){t.setAttribute('data-removed','');layout();setTimeout(function(){t.remove();},300);}
    document.addEventListener('visibilitychange',function(){if(document.hidden){clearTimeout(timer);left-=Date.now()-start;}else run();});
    run();
  }

  /* ---------- Kopiera ---------- */
  function selectText(el){var r=document.createRange();r.selectNodeContents(el);var s=getSelection();s.removeAllRanges();s.addRange(r);}
  document.querySelectorAll('[data-copy]').forEach(function(b){
    b.addEventListener('click',function(){
      var el=document.getElementById(b.dataset.target),text=el?el.textContent.trim():'';
      var fail=function(){if(el)selectText(el);toast('Texten är markerad. Kopiera den med Ctrl+C eller ⌘+C.');};
      try{navigator.clipboard.writeText(text).then(function(){toast(b.dataset.toast||'Kopierat');},fail);}catch(e){fail();}
    });
  });

  /* ---------- Demo: blippa brickan ---------- */
  var demo=document.querySelector('[data-demo]');
  if(demo){
    var cap=demo.querySelector('[data-caption]'),stars=[].slice.call(demo.querySelectorAll('.star'));
    var captions={idle:'Tryck på brickan som om din mobil höll mot den.',open:'Så här möter kunden dig. På riktigt öppnas ditt recensionsformulär på Google.',done:'Klart på några sekunder, utan att leta upp rätt sida.'};
    function set(s){demo.dataset.state=s;cap.textContent=captions[s];}
    function paint(n){stars.forEach(function(s,i){s.classList.toggle('on',i<n);});}
    demo.querySelector('[data-tap]').addEventListener('click',function(){
      demo.classList.remove('burst');void demo.offsetWidth;demo.classList.add('burst');
      set('open');setTimeout(function(){stars[4].focus({preventScroll:true});},reduce?0:420);
    });
    stars.forEach(function(s,i){
      if(matchMedia('(hover: hover) and (pointer: fine)').matches){s.addEventListener('mouseenter',function(){paint(i+1);});}
      s.addEventListener('click',function(){paint(i+1);setTimeout(function(){set('done');demo.querySelector('[data-reset]').focus({preventScroll:true});},reduce?0:320);});
    });
    demo.querySelector('.stars-row').addEventListener('mouseleave',function(){if(demo.dataset.state==='open')paint(0);});
    demo.querySelector('[data-reset]').addEventListener('click',function(){paint(0);demo.classList.remove('burst');set('idle');demo.querySelector('[data-tap]').focus({preventScroll:true});});
  }

  /* ---------- Tabbar med clip-path ---------- */
  var tabs=document.querySelector('[data-tabs]');
  if(tabs){
    var btns=[].slice.call(tabs.querySelectorAll('[role="tab"]')),active=tabs.querySelector('.tab-list-active');
    function clip(btn){var w=tabs.offsetWidth,l=btn.offsetLeft,r=w-(l+btn.offsetWidth);active.style.clipPath='inset(0 '+(r/w*100)+'% 0 '+(l/w*100)+'%)';}
    function select(btn,focus,quiet){
      btns.forEach(function(b){var on=b===btn;b.setAttribute('aria-selected',on);b.tabIndex=on?0:-1;var p=document.getElementById(b.getAttribute('aria-controls'));
        if(on&&p.hidden){p.hidden=false;p.classList.remove('enter');void p.offsetWidth;p.classList.add('enter');}else if(!on)p.hidden=true;});
      clip(btn);if(focus)btn.focus();
      var vis=document.querySelector('.svc-vis');if(vis)vis.dataset.vis=btn.dataset.hash==='hemsidor'?'web':'nfc';
      if(!quiet){var r=document.createElement('span');r.className='tab-blip';r.style.left=(btn.offsetLeft+btn.offsetWidth/2)+'px';r.style.top=(btn.offsetTop+btn.offsetHeight/2)+'px';tabs.appendChild(r);setTimeout(function(){r.remove();},700);}
      if(btn.dataset.hash&&history.replaceState)history.replaceState(null,'','#'+btn.dataset.hash);
    }
    btns.forEach(function(b,i){
      b.addEventListener('click',function(){select(b);});
      b.addEventListener('keydown',function(e){var n=e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0;if(n){e.preventDefault();select(btns[(i+n+btns.length)%btns.length],true);}});
    });
    var initial=btns.filter(function(b){return '#'+b.dataset.hash===location.hash;})[0];if(initial&&initial!==btns[0]){select(initial,false,true);}
    active.style.transition='none';clip(tabs.querySelector('[aria-selected="true"]'));requestAnimationFrame(function(){active.style.transition='';});
    addEventListener('resize',function(){clip(tabs.querySelector('[aria-selected="true"]'));});
    if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){active.style.transition='none';clip(tabs.querySelector('[aria-selected="true"]'));requestAnimationFrame(function(){active.style.transition='';});});
  }

  /* ---------- Accordion ---------- */
  document.querySelectorAll('.acc-trigger').forEach(function(t){
    t.addEventListener('click',function(){var open=t.getAttribute('aria-expanded')!=='true';t.setAttribute('aria-expanded',open);t.parentNode.classList.toggle('open',open);});
  });

  /* ---------- Mobilmeny ---------- */
  var mb=document.querySelector('.menu-btn'),menu=document.getElementById('menu');
  if(mb&&menu){
    function setMenu(o){menu.classList.toggle('open',o);mb.setAttribute('aria-expanded',o);mb.textContent=o?'Stäng':'Meny';}
    mb.addEventListener('click',function(e){e.stopPropagation();setMenu(!menu.classList.contains('open'));});
    document.addEventListener('click',function(e){if(menu.classList.contains('open')&&!menu.contains(e.target))setMenu(false);});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&menu.classList.contains('open')){setMenu(false);mb.focus();}});
  }

  /* ---------- Formulär ---------- */
  var form=document.getElementById('contact-form');
  if(form){
    if(location.hash==='#uf'){var tp=document.getElementById('topic');tp.value='Hemsida för UF-företag (499 kr)';var msg=document.getElementById('message');msg.value='Hej! Vi driver ett UF-företag och vill ha en hemsida för 499 kr.';var co=document.getElementById('company');co.value='';}
    var sent=document.getElementById('sent'),out=document.getElementById('sent-text');
    form.addEventListener('submit',function(e){
      e.preventDefault();var ok=true;
      [['name','Skriv ditt namn.'],['email','Skriv en e-postadress vi kan svara på.'],['message','Berätta kort vad du behöver hjälp med.']].forEach(function(f){
        var el=document.getElementById(f[0]),er=document.getElementById(f[0]+'-err'),v=el.value.trim(),bad=!v||(f[0]==='email'&&!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v));
        el.setAttribute('aria-invalid',bad);er.textContent=bad?(f[0]==='email'&&v?'E-postadressen ser inte rätt ut. Kontrollera den.':f[1]):'';if(bad&&ok){el.focus();ok=false;}
      });
      if(!ok)return;
      var g=function(id){return document.getElementById(id).value.trim();};
      var text='Hej Blipyfy!\n\n'+g('message')+'\n\nGäller: '+g('topic')+'\n\n'+g('name')+(g('company')?'\n'+g('company'):'')+'\n'+g('email')+(g('phone')?'\n'+g('phone'):'');
      function showCopy(failed){out.textContent=text;if(failed){document.getElementById('sent-title').textContent='Det gick inte att skicka';document.getElementById('sent-note').innerHTML='Något gick fel. Kopiera texten och mejla den till <strong>kundtjanst@blipyfy.se</strong> i stället.';}
        form.hidden=true;sent.hidden=false;sent.querySelector('h2').focus();}
      var ep=form.dataset.endpoint;
      if(!ep){showCopy(false);return;}
      var btn=form.querySelector('[type="submit"]');btn.disabled=true;btn.textContent='Skickar…';
      fetch(ep,{method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json'},body:JSON.stringify({namn:g('name'),foretag:g('company'),email:g('email'),telefon:g('phone'),galler:g('topic'),meddelande:g('message'),_replyto:g('email'),_subject:'Ny förfrågan: '+g('topic'),_gotcha:form.querySelector('[name="_gotcha"]').value})})
        .then(function(r){if(!r.ok)throw 0;form.hidden=true;var d=document.getElementById('done');d.hidden=false;d.querySelector('h2').focus();form.reset();})
        .catch(function(){showCopy(true);})
        .then(function(){btn.disabled=false;btn.textContent='Skicka';});
    });
    document.getElementById('edit-again').addEventListener('click',function(){sent.hidden=true;form.hidden=false;document.getElementById('message').focus();});
  }
})();
(function(){
  /* 1. Stryk över kostnaderna när de syns */
  var els=document.querySelectorAll('[data-inview]');
  if(els.length){
    if(!('IntersectionObserver' in window)){els.forEach(function(e){e.classList.add('in');});}
    else{var io=new IntersectionObserver(function(en){en.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target);}});},{rootMargin:'0px 0px -20% 0px'});els.forEach(function(e){io.observe(e);});}
  }
  /* 2. Hemsida som anpassar sig: desktop -> mobil -> https */
  var sc=document.querySelector('[data-showcase]');
  if(sc){
    var red=matchMedia('(prefers-reduced-motion: reduce)').matches,timers=[];
    function play(){timers.forEach(clearTimeout);timers=[];
      if(red){sc.dataset.step='3';return;}
      sc.dataset.step='0';void sc.offsetWidth;
      [[800,'1'],[2900,'2'],[4300,'3']].forEach(function(t){timers.push(setTimeout(function(){sc.dataset.step=t[1];},t[0]));});}
    if('IntersectionObserver' in window){var o=new IntersectionObserver(function(e){if(e[0].isIntersecting){play();o.disconnect();}},{rootMargin:'0px 0px -25% 0px'});o.observe(sc);}else play();
    sc.querySelector('[data-replay]').addEventListener('click',play);
  }
})();

